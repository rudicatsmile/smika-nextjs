1:"$Sreact.fragment"
2:I[32026,["5210","static/chunks/5210-f2ee7feb7c12b947.js","6609","static/chunks/6609-078a8cdc853f87c6.js","4841","static/chunks/4841-c1c381cc1422674c.js","7882","static/chunks/7882-1671d144bf460571.js","5392","static/chunks/5392-9fe7ba4af72dd664.js","7177","static/chunks/app/layout-8e3630fa7c6a7cfc.js"],"Providers"]
3:I[57121,[],""]
4:I[74581,[],""]
:HL["/_next/static/css/1ee804c6149c71b5.css","style"]
:HL["/_next/static/css/d6ec4121e368f3c2.css","style"]
0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/1ee804c6149c71b5.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/css/d6ec4121e368f3c2.css","precedence":"next"}]],["$","html",null,{"lang":"id","className":"__variable_d8ebd1 __variable_532bb9 h-full antialiased","suppressHydrationWarning":true,"children":["$","body",null,{"className":"min-h-full","suppressHydrationWarning":true,"children":["$","$L2",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]}]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"mUnYqtCXpQAbL0nXPQlrT"}
