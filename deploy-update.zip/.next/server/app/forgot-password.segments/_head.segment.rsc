1:"$Sreact.fragment"
2:I[90484,[],"ViewportBoundary"]
3:I[90484,[],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[86869,[],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"SIMKA Al Wathoniyah 9"}],["$","meta","1",{"name":"description","content":"Sistem Informasi Kepegawaian Al Wathoniyah 9"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?ad99d0d60749cadb","type":"image/x-icon","sizes":"16x16"}],["$","link","3",{"rel":"icon","href":"/favicon.ico"}],["$","$L5","4",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"mUnYqtCXpQAbL0nXPQlrT"}
