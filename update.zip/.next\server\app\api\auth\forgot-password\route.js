var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/forgot-password/route.js")
R.c("server/chunks/[root-of-the-server]__00fra64._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_025zt.d._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_forgot-password_route_actions_0txet3j.js")
R.m(88810)
module.exports=R.m(88810).exports
