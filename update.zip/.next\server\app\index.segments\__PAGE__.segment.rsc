1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/0.rmamdhn563w.js","/_next/static/chunks/0ai1-rhgvrirk.js","/_next/static/chunks/01z6o.76kaymo.js","/_next/static/chunks/0j2jr_a9~y~wn.js","/_next/static/chunks/0a3em96gaa4d2.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"AmD_PguArkBtPHIBXolMI"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/login;307;"}
