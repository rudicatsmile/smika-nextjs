var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/pegawai/template/route.js")
R.c("server/chunks/[root-of-the-server]__0-9m3h9._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/node_modules_xlsx_xlsx_mjs_0eepc5h._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_next-internal_server_app_api_pegawai_template_route_actions_10wj8lw.js")
R.m(87661)
module.exports=R.m(87661).exports
