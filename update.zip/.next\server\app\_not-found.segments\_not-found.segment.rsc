1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0.rmamdhn563w.js","/_next/static/chunks/0ai1-rhgvrirk.js","/_next/static/chunks/01z6o.76kaymo.js","/_next/static/chunks/0j2jr_a9~y~wn.js","/_next/static/chunks/0a3em96gaa4d2.js"],"default"]
3:I[37457,["/_next/static/chunks/0.rmamdhn563w.js","/_next/static/chunks/0ai1-rhgvrirk.js","/_next/static/chunks/01z6o.76kaymo.js","/_next/static/chunks/0j2jr_a9~y~wn.js","/_next/static/chunks/0a3em96gaa4d2.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"AmD_PguArkBtPHIBXolMI"}
