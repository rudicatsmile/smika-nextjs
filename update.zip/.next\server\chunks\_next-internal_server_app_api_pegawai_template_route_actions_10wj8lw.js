module.exports=[16027,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pegawai_template_route_actions_10wj8lw.js.map