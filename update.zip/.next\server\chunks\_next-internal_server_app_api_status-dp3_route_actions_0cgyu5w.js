module.exports=[92875,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_status-dp3_route_actions_0cgyu5w.js.map