var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0wy_eyj._.js")
R.c("server/chunks/[root-of-the-server]__06ulst5._.js")
R.m(62395)
module.exports=R.m(62395).exports
