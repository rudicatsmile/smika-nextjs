var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/uploads/route.js")
R.c("server/chunks/[root-of-the-server]__0wzq0cs._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_0bwykn1._.js")
R.c("server/chunks/_025zt.d._.js")
R.c("server/chunks/_next-internal_server_app_api_uploads_route_actions_0i8si8u.js")
R.m(31081)
module.exports=R.m(31081).exports
