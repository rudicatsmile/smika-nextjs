var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/pegawai/import/route.js")
R.c("server/chunks/[root-of-the-server]__11okcg2._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_025zt.d._.js")
R.c("server/chunks/_0bwykn1._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_next-internal_server_app_api_pegawai_import_route_actions_0jsq6w7.js")
R.m(91027)
module.exports=R.m(91027).exports
