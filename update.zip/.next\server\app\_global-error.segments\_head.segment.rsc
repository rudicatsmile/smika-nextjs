1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/01z6o.76kaymo.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/01z6o.76kaymo.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/01z6o.76kaymo.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.0rzvijyk12dj8.ico","sizes":"64x64","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"AmD_PguArkBtPHIBXolMI"}
