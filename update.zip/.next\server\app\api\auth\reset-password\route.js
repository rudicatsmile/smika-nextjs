var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/reset-password/route.js")
R.c("server/chunks/[root-of-the-server]__0.1xl2u._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_025zt.d._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_reset-password_route_actions_0jqvzj8.js")
R.m(18063)
module.exports=R.m(18063).exports
