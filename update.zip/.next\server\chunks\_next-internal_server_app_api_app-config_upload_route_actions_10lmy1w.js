module.exports=[21722,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_app-config_upload_route_actions_10lmy1w.js.map