var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/years/route.js")
R.c("server/chunks/[root-of-the-server]__0ife70d._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_025zt.d._.js")
R.c("server/chunks/_next-internal_server_app_api_years_route_actions_05hupj2.js")
R.m(96679)
module.exports=R.m(96679).exports
