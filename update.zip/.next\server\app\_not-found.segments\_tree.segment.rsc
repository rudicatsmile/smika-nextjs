:HL["/_next/static/chunks/0elyhj9srdadb.css","style"]
:HL["/_next/static/chunks/0ibwz-hezqz.3.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"AmD_PguArkBtPHIBXolMI"}
