var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/status-dp3/route.js")
R.c("server/chunks/[root-of-the-server]__0cmubvx._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_025zt.d._.js")
R.c("server/chunks/_next-internal_server_app_api_status-dp3_route_actions_0cgyu5w.js")
R.m(26278)
module.exports=R.m(26278).exports
