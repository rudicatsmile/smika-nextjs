globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/AmD_PguArkBtPHIBXolMI/_buildManifest.js",
    "static/AmD_PguArkBtPHIBXolMI/_ssgManifest.js",
    "static/AmD_PguArkBtPHIBXolMI/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0yb2wil16uz6h.js",
    "static/chunks/05cb37z0kpq1b.js",
    "static/chunks/0s2kfwao_cxaa.js",
    "static/chunks/0.~f.7kqowpj0.js",
    "static/chunks/141elbm8h_6da.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/turbopack-0q_cc7cky6gqj.js"
  ]
};
