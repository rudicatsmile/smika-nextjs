var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/app-config/upload/route.js")
R.c("server/chunks/[root-of-the-server]__0yl32zq._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__13~sq24._.js")
R.c("server/chunks/_0bwykn1._.js")
R.c("server/chunks/_025zt.d._.js")
R.c("server/chunks/_next-internal_server_app_api_app-config_upload_route_actions_10lmy1w.js")
R.m(86004)
module.exports=R.m(86004).exports
